package com.webdriver.basic;

import com.sun.xml.internal.stream.buffer.stax.StreamWriterBufferCreator;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.RemoteWebDriver;
import com.google.common.base.Function;
import org.openqa.selenium.*;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import java.util.concurrent.TimeUnit;

/**
 * Created by Artsiom_Halavach1 on 12/20/2017.
 */
public class WebDriverTest {
    private static final String MAINPAGE = "https://uk.practicallaw.thomsonreuters.com/";
    private static final String ASK_FORM = "//*[@id=\'co_pageHeader\']/div[2]/div/a";
    private WebDriver driver;
    private WebElement askFormBtn;
    private WebElement textInput;
//    private WebDriver driver = new FirefoxDriver();
//
//    public CommonMethods() {
//        super(driver);
//    }



    @BeforeClass(description = "Start browser")
    public void startBrowser() {
        //alternative way to set environmental variable at runtime
        System.setProperty("webdriver.chrome.driver", "d:\\chromedriver.exe");
        ChromeOptions options = new ChromeOptions();

//        FirefoxOptions options = new FirefoxOptions();


        options.addArguments("start-maximized");
        driver = new ChromeDriver(options);
//        driver = new FirefoxDriver(options);
        driver.manage().window().fullscreen();
        driver.get(MAINPAGE);

        // setting standard timeout
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        driver.findElement(By.cssSelector("#CookieConsentMessageClose")).click();

    }



//    @BeforeTest
//    public void backToHome () {
//        driver.get(MAINPAGE);
//    }



//  AskForm
@Test
public void AskFormexecutaion () throws Exception {

    askFormBtn = driver.findElement(By.xpath(ASK_FORM));
    askFormBtn.click();
    String winHandleBefore = driver.getWindowHandle();

//        Switch to ASK window form
    for (String winHandle : driver.getWindowHandles()) {
        driver.switchTo().window(winHandle);
    }
    String winHandleAsk = driver.getWindowHandle();
//        Set up details
    driver.findElement(By.cssSelector("#IsCheckedTerms")).click();
    driver.findElement(By.id("FirstName")).sendKeys("Artsiom");
    driver.findElement(By.id("LastName")).sendKeys("Halavach");
    driver.findElement(By.id("Email")).sendKeys("test@google.com");

    Select orgType = new Select(driver.findElement(By.cssSelector("#OrganisationType")));
    orgType.selectByVisibleText("Public Sector");

    Select position = new Select(driver.findElement(By.cssSelector("#Position")));
    position.selectByVisibleText("Legal Advisor");

    Select jurisdiction = new Select(driver.findElement(By.cssSelector("#Jurisdiction")));
    jurisdiction.selectByVisibleText("UK");

    Select answeringService = new Select(driver.findElement(By.cssSelector("#AnsweringService")));
    answeringService.selectByVisibleText("Tax");

    driver.findElement(By.cssSelector("#cancelAskFormButton")).click();

    Assert.assertFalse(driver.getWindowHandles().contains("winHandleAsk"), "still appearing");

}

//  Twitter
    @Test
    public void twitterTest () throws InterruptedException {


        driver.manage().timeouts().pageLoadTimeout(15, TimeUnit.SECONDS);
//        driver.manage().window().
        ((JavascriptExecutor) driver).executeScript("scroll(0,2000)");
        JavascriptExecutor js = ((JavascriptExecutor) driver);
//        driver.wait(5);
//        js.executeAsyncScript("window.scrollBy(0,250)");
//        js.executeAsyncScript("window.scrollBy(0,250)");
        js.executeScript("window.scrollTo(0, document.body.scrollHeight)");
        js.executeScript("window.scrollBy(0,25000)", "");
//        driver.wait(5);
        js.executeScript("window.scrollBy(0,250)", "");


        js.executeScript("arguments[0].scrollIntoView(true);",  driver.findElement(By.xpath("//div[@id='twitter-links']//ul[@class='co_dropDownMenuList']")));
//        driver.findElement(By.id("coid_websiteFooter_helplink")).click();
        driver.findElement(By.xpath("//div[@id='twitter-links']//ul[@class='co_dropDownMenuList']")).click();
//        driver.manage().timeouts().pageLoadTimeout(15, TimeUnit.SECONDS);
        js.executeAsyncScript("window.scrollBy(0,250)");



    }


//    @AfterClass(description = "Stop Browser")
//    public void stopBrowser() {
//        driver.quit();
//        System.out.println("Browser was successfully quited.");
//    }



}

